# iWantSexNow.ch – Lovable Logo Pack (SVG)

This pack contains **5 concept directions**, each with:
- `horizontal.svg` (icon + wordmark)
- `stacked.svg` (icon above wordmark)
- `icon.svg` (icon only)

## How to use in Lovable / Next.js
1) Upload the SVGs to your assets folder (e.g. `/public/brand/`).
2) Use them like:
```jsx
<img src="/brand/c02-horizontal.svg" alt="iWantSexNow.ch" height={32} />
```

## Colors
All SVGs support CSS variables:
- `--ink` (default charcoal)
- `--accent` (default burgundy)

Example (Tailwind):
```jsx
<div style={{"--ink":"#111", "--accent":"#6B1B3D"}}>
  <img src="/brand/c02-icon.svg" alt="Icon" width={48} height={48}/>
</div>
```

For monochrome, set `--accent` = `--ink` or set both to `currentColor` and control via CSS.

## Notes
- Typography is set via `font-family` fallbacks:
  - Serif: `Playfair Display`, `Didot`, `Bodoni`, `Georgia`
  - Sans: `Inter`, `Helvetica Neue`, `Arial`
- For perfect brand-match, load your chosen Google Fonts on the site.
